# main.py

from calculator import add, subtract, multiply, divide
from utils import is_number

print("Welcome to the simple calculator!")

a = input("Enter first number: ")
b = input("Enter second number: ")

if is_number(a) and is_number(b):
    a = float(a)
    b = float(b)
    print("Sum:", add(a, b))
    print("Difference:", subtract(a, b))
    print("Product:", multiply(a, b))
    print("Quotient:", divide(a, b))
else:
    print("Invalid input. Please enter numbers.")
